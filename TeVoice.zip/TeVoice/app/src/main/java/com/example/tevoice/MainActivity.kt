package com.example.tevoice

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.databinding.DataBindingUtil
import com.example.tevoice.databinding.ActivityMainBinding
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale

class MainActivity : AppCompatActivity() {

    val recognizer= TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    lateinit var tts:TextToSpeech

    lateinit var binding: ActivityMainBinding

    private val REQUEST_IMAGE_CAPTURE=1

    private var imageBitmap:Bitmap?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding=DataBindingUtil.setContentView(this,R.layout.activity_main)

        binding.apply {

            captureImage.setOnClickListener {

                takeImage()

                textView.text=""
            }

            detect.setOnClickListener {

                processImage()


            }
        }

        var b1 = findViewById<Button>(R.id.voice)
        var t1 = findViewById<TextView>(R.id.text_view)

        b1.setOnClickListener {
            tts = TextToSpeech(applicationContext, TextToSpeech.OnInitListener {
                if (it==TextToSpeech.SUCCESS) {

                    tts.language = Locale.US
                    tts.setSpeechRate(1.0f)
                    tts.speak(t1.text.toString(), TextToSpeech.QUEUE_ADD,null)
                }
            })
        }


    }

    private fun processImage() {

        if (imageBitmap!=null){

            val image=imageBitmap?.let {

                InputImage.fromBitmap(it,0)

            }

            image?.let {

                recognizer.process(it)
                    .addOnSuccessListener {

                        binding.textView.text=it.text

                    }
                    .addOnFailureListener {

                        Toast.makeText(this, "Nothing to show", Toast.LENGTH_SHORT).show()

                    }
            }

        }

        else{

            Toast.makeText(this, "Please select image first", Toast.LENGTH_SHORT).show()
        }

    }

    private fun takeImage() {

        val intent=Intent(MediaStore.ACTION_IMAGE_CAPTURE)

        intent.putExtra(MediaStore.EXTRA_BRIGHTNESS,1)

        try {

            startActivityForResult(intent,REQUEST_IMAGE_CAPTURE)
        }
        catch (e:Exception){

        }


    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)


        if (requestCode==REQUEST_IMAGE_CAPTURE && resultCode== RESULT_OK){

            val extras:Bundle?=data?.extras

            imageBitmap=extras?.get("data") as Bitmap

            if (imageBitmap!=null){
                binding.imageView.setImageBitmap(imageBitmap)
            }

        }


    }

}